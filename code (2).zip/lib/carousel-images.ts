export const CAROUSEL_IMAGES = [
  '/car-accessories-family-4k.jpg',
  '/car-gps-navigation-system-dashboard-touchscreen.jpg',
  '/car-head-unit-multimedia-player.jpg',
  '/car-audio-speakers-subwoofer-installation.jpg',
] as const

export const CAROUSEL_INTERVAL = 3000
