'use client'

import { useState } from 'react'
import Header from '@/components/header'
import Footer from '@/components/footer'
import WhatsAppFloatButton from '@/components/whatsapp-float-button'
import { translations, type Language } from '@/lib/translations'
import { Star, Camera, Zap, Shield, Wifi } from 'lucide-react'

export default function DashboardCameraProductPage() {
  const [language, setLanguage] = useState<Language>('en')
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const images = [
    '/car-accessories-family-4k.jpg',
    '/car-gps-navigation-system-dashboard-touchscreen.jpg',
    '/car-head-unit-multimedia-player.jpg',
    '/car-audio-speakers-subwoofer-installation.jpg',
  ]

  // Auto-rotate images every 3 seconds
  setTimeout(() => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length)
  }, 3000)

  const isArabic = language === 'ar'
  const textDir = isArabic ? 'rtl' : 'ltr'

  const productData = {
    name: '4K Dashboard Camera with Night Vision',
    nameAr: 'كاميرا لوحة التحكم 4K مع الرؤية الليلية',
    price: 179.99,
    rating: 4.7,
    reviews: 234,
    compatibility: 'Universal Fit - All Vehicles',
    compatibilityAr: 'مناسب لجميع السيارات',
    description: 'Professional 4K dashboard camera with advanced night vision, GPS tracking, and cloud backup capabilities.',
    descriptionAr: 'كاميرا لوحة تحكم احترافية 4K مع رؤية ليلية متقدمة وتتبع GPS وإمكانيات النسخ الاحتياطي السحابي.',
    specs: [
      { title: '4K Resolution', titleAr: 'دقة 4K', icon: Camera },
      { title: 'Night Vision', titleAr: 'رؤية ليلية', icon: Shield },
      { title: 'GPS Tracking', titleAr: 'تتبع GPS', icon: Zap },
      { title: 'WiFi Enabled', titleAr: 'تفعيل WiFi', icon: Wifi },
    ],
    features: [
      { en: '4K UHD Video Recording', ar: 'تسجيل فيديو 4K UHD' },
      { en: 'Advanced Night Vision', ar: 'رؤية ليلية متقدمة' },
      { en: 'GPS & Speed Tracking', ar: 'تتبع GPS والسرعة' },
      { en: 'WiFi Live Streaming', ar: 'البث المباشر عبر WiFi' },
      { en: 'Cloud Backup System', ar: 'نظام النسخ الاحتياطي السحابي' },
      { en: 'Wide 170° Field of View', ar: 'زاوية رؤية واسعة 170°' },
      { en: 'Emergency Recording Mode', ar: 'وضع التسجيل الطارئ' },
      { en: 'Mobile App Control', ar: 'التحكم عبر تطبيق الجوال' },
    ],
    technicalSpecs: [
      { label: 'Resolution', labelAr: 'الدقة', value: '4K @ 30fps' },
      { label: 'Sensor', labelAr: 'المستشعر', value: '1/1.3 inch CMOS' },
      { label: 'Lens', labelAr: 'العدسة', value: 'F2.0 170° Wide Angle' },
      { label: 'Night Vision', labelAr: 'الرؤية الليلية', value: 'IR LED Enhanced' },
      { label: 'Storage', labelAr: 'التخزين', value: 'microSD up to 256GB' },
      { label: 'Connectivity', labelAr: 'الاتصالية', value: 'WiFi 5G, Bluetooth, GPS' },
    ],
  }

  return (
    <main className="min-h-screen bg-background" dir={textDir}>
      <Header />

      {/* Hero Section */}
      <section className="relative min-h-96 flex items-center justify-center overflow-hidden pt-20 pb-12">
        {images.map((img, idx) => (
          <div
            key={idx}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              idx === currentImageIndex ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `url('${img}')`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              backgroundRepeat: 'no-repeat',
            }}
          />
        ))}
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />

        <div className="relative z-10 text-center px-4 md:px-6 max-w-3xl animate-fade-in-up">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-balance">
            {isArabic ? productData.nameAr : productData.name}
          </h1>
          <p className="text-lg md:text-xl text-white/80 text-balance">
            {isArabic ? productData.descriptionAr : productData.description}
          </p>
        </div>
      </section>

      {/* Language Switcher */}
      <div className="flex justify-center gap-4 py-8 px-4 relative z-20">
        <button
          onClick={() => setLanguage('en')}
          className={`px-6 py-2 rounded-lg font-semibold transition-all duration-300 ${
            language === 'en'
              ? 'bg-blue-500 text-white shadow-lg'
              : 'bg-white/10 backdrop-blur-sm text-white/60 hover:text-white'
          }`}
        >
          English
        </button>
        <button
          onClick={() => setLanguage('ar')}
          className={`px-6 py-2 rounded-lg font-semibold transition-all duration-300 ${
            language === 'ar'
              ? 'bg-blue-500 text-white shadow-lg'
              : 'bg-white/10 backdrop-blur-sm text-white/60 hover:text-white'
          }`}
        >
          العربية
        </button>
      </div>

      {/* Product Overview */}
      <section className="relative py-16 px-4 md:px-6">
        <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" />
        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Product Image */}
            <div className="lg:col-span-1">
              <div className="sticky top-20 bg-white/10 backdrop-blur-md rounded-xl overflow-hidden border border-white/20 p-4">
                <img
                  src="/car-gps-navigation-system-dashboard-touchscreen.jpg"
                  alt={productData.name}
                  className="w-full h-80 object-cover rounded-lg"
                />
              </div>
            </div>

            {/* Product Details */}
            <div className="lg:col-span-2">
              <div className="space-y-6">
                {/* Rating */}
                <div className="flex items-center gap-4">
                  <div className="flex gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={20}
                        className={`${
                          i < Math.floor(productData.rating)
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-gray-600'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-white/70">
                    {productData.rating} ({productData.reviews} {isArabic ? 'تقييم' : 'reviews'})
                  </span>
                </div>

                {/* Price */}
                <div>
                  <p className="text-4xl font-bold text-blue-400 mb-2">${productData.price}</p>
                  <p className="text-white/60">
                    {isArabic ? 'تشمل جميع الضرائب والرسوم' : 'All taxes and fees included'}
                  </p>
                </div>

                {/* Key Features */}
                <div className="grid grid-cols-2 gap-4">
                  {productData.specs.map((spec, idx) => {
                    const Icon = spec.icon
                    return (
                      <div
                        key={idx}
                        className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/10 hover:border-blue-400/50 transition-all duration-300 group"
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <Icon size={24} className="text-blue-400 group-hover:text-blue-300 transition-colors" />
                          <span className="font-semibold text-white">{isArabic ? spec.titleAr : spec.title}</span>
                        </div>
                      </div>
                    )
                  })}
                </div>

                {/* CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <a
                    href="https://wa.me/1234567890?text=I'm%20interested%20in%204K%20Dashboard%20Camera"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg font-bold transition-all duration-300 transform hover:scale-105 text-center"
                  >
                    {isArabic ? 'اطلب الآن عبر WhatsApp' : 'Order via WhatsApp'}
                  </a>
                  <button className="flex-1 px-6 py-3 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 rounded-lg font-bold transition-all duration-300 border border-blue-400/50">
                    {isArabic ? 'احفظ للاحقا' : 'Save for Later'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-16 px-4 md:px-6">
        <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" />
        <div className="relative z-10 max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-12 text-center">
            {isArabic ? 'المميزات الرئيسية' : 'Key Features'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {productData.features.map((feature, idx) => (
              <div
                key={idx}
                className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/20 hover:border-blue-400/50 transition-all duration-300 transform hover:scale-105"
                style={{ animation: `fadeInUp 0.6s ease-out ${idx * 0.1}s backwards` }}
              >
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-blue-400 mt-2 flex-shrink-0" />
                  <p className="text-white/80">{isArabic ? feature.ar : feature.en}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="relative py-16 px-4 md:px-6">
        <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" />
        <div className="relative z-10 max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">
            {isArabic ? 'المواصفات التقنية' : 'Technical Specifications'}
          </h2>
          <div className="bg-white/10 backdrop-blur-md rounded-xl overflow-hidden border border-white/20">
            <div className="divide-y divide-white/10">
              {productData.technicalSpecs.map((spec, idx) => (
                <div key={idx} className="p-4 md:p-6 flex items-center justify-between hover:bg-white/5 transition-colors">
                  <span className="font-semibold text-white/80">{isArabic ? spec.labelAr : spec.label}</span>
                  <span className="text-blue-300">{spec.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppFloatButton />
    </main>
  )
}
