'use client'

import { useState } from 'react'
import Header from '@/components/header'
import Footer from '@/components/footer'
import WhatsAppFloatButton from '@/components/whatsapp-float-button'
import ProductsHero from '@/components/products-hero'
import LanguageSwitcher from '@/components/language-switcher'
import ProductCard from '@/components/product-card'
import ProductsCTA from '@/components/products-cta'
import { products } from '@/lib/products-data'
import { type Language } from '@/lib/translations'

export default function ProductsPage() {
  const [language, setLanguage] = useState<Language>('en')
  const isArabic = language === 'ar'
  const textDir = isArabic ? 'rtl' : 'ltr'

  return (
    <main className="min-h-screen bg-background" dir={textDir}>
      <Header />

      {/* Hero Section */}
      <ProductsHero language={language} />

      {/* Language Switcher */}
      <LanguageSwitcher language={language} onLanguageChange={setLanguage} />

      {/* Products Grid */}
      <section className="relative py-16 px-4 md:px-6">
        <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" />

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <ProductCard key={product.id} product={product} language={language} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <ProductsCTA language={language} />

      <Footer />
      <WhatsAppFloatButton />
    </main>
  )
}
