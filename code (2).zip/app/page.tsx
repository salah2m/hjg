import { Car, Smartphone, Headphones, Zap, Volume2, MapPin, MessageCircle } from 'lucide-react'
import Header from '@/components/header'
import Hero from '@/components/hero'
import Features from '@/components/features'
import Specifications from '@/components/specifications'
import Gallery from '@/components/gallery'
import Testimonials from '@/components/testimonials'
import ContactCTA from '@/components/contact-cta'
import Footer from '@/components/footer'
import WhatsAppFloatButton from '@/components/whatsapp-float-button'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import ProductCard from '@/components/product-card'
import { products } from '@/lib/products-data'

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Hero />
      <Features />
      <Specifications />
      <Gallery />
      <Testimonials />
      <ContactCTA />
      
      {/* Featured Products Section showing top 3 products */}
      <section className="relative py-16 px-4 md:px-6 lg:px-8 bg-gradient-to-br from-slate-900/50 via-black/50 to-blue-900/50 backdrop-blur-md border-t border-b border-blue-500/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 text-balance">
              Featured Products
            </h2>
            <p className="text-white/70 mb-8 text-balance">
              Our bestselling car audio and navigation systems designed for modern vehicles
            </p>
          </div>
          
          {/* Featured Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {products.slice(0, 3).map((product, index) => (
              <ProductCard key={product.id} product={product} language="en" index={index} />
            ))}
          </div>

          {/* View All Products CTA */}
          <div className="text-center">
            <Link href="/products">
              <Button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 text-lg font-semibold rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/50">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      <Footer />
      <WhatsAppFloatButton />
    </main>
  )
}
