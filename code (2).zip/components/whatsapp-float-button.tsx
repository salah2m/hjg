'use client';

import { MessageCircle } from 'lucide-react';

export default function WhatsAppFloatButton() {
  return (
    <a
      href="https://wa.me/212XXXXXXXXX?text=Hello%20I%20am%20interested%20in%20your%20car%20radio%20systems"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center justify-center w-14 h-14 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-full shadow-lg transition-all duration-300 hover:scale-110 hover:shadow-2xl animate-pulse"
      title="Chat on WhatsApp"
    >
      <MessageCircle className="w-7 h-7" />
    </a>
  );
}
