'use client'

import { type Language } from '@/lib/translations'

interface ProductsCTAProps {
  language: Language
}

export default function ProductsCTA({ language }: ProductsCTAProps) {
  const isArabic = language === 'ar'

  return (
    <section className="relative py-16 px-4 md:px-6 mb-12">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" />

      <div className="relative z-10 max-w-2xl mx-auto text-center animate-fade-in-up">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 text-balance">
          {isArabic ? 'لم تجد ما تبحث عنه؟' : "Can't find what you're looking for?"}
        </h2>
        <p className="text-white/70 mb-8 text-balance">
          {isArabic
            ? 'اتصل بنا عبر WhatsApp للحصول على استشارة مخصصة'
            : 'Contact us via WhatsApp for personalized consultation'}
        </p>
        <a
          href="https://wa.me/1234567890?text=Hello%20I%20would%20like%20to%20know%20more%20about%20your%20products"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block px-8 py-4 bg-green-500 hover:bg-green-600 text-white rounded-lg font-bold text-lg transition-all duration-300 transform hover:scale-105"
        >
          {isArabic ? 'اتصل بنا الآن' : 'Contact Us Now'}
        </a>
      </div>
    </section>
  )
}
