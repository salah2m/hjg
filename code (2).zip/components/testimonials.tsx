'use client'

import { useState, useEffect } from 'react'
import { Star, ChevronLeft, ChevronRight } from 'lucide-react'

interface Testimonial {
  id: number
  name: string
  role: string
  rating: number
  comment: string
  avatar: string
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Ahmed Al-Rashid',
    role: 'Peugeot 208 Owner',
    rating: 5,
    comment: 'Fantastic quality and installation was smooth. The wireless CarPlay works perfectly and the GPS navigation is incredibly accurate. Highly recommend!',
    avatar: '👤'
  },
  {
    id: 2,
    name: 'Fatima Mohamed',
    role: 'Peugeot 2008 Owner',
    rating: 5,
    comment: 'Best upgrade I made to my car. The sound quality is exceptional, and the interface is very intuitive. Customer service was excellent!',
    avatar: '👤'
  },
  {
    id: 3,
    name: 'Mohammed Hassan',
    role: 'Car Enthusiast',
    rating: 5,
    comment: 'The Android 15 system is lightning fast. 8-core DSP gives amazing audio quality. Worth every penny. Already recommended to my friends.',
    avatar: '👤'
  },
  {
    id: 4,
    name: 'Sarah Al-Omani',
    role: 'Daily Commuter',
    rating: 5,
    comment: 'Amazing experience! The touch screen is super responsive and the Bluetooth connectivity is rock solid. Love the RDS radio feature too.',
    avatar: '👤'
  },
]

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const [itemsPerPage, setItemsPerPage] = useState(1)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const backgroundImages = [
    '/car-accessories-family-4k.jpg',
    '/car-gps-navigation-system-dashboard-touchscreen.jpg',
    '/car-head-unit-multimedia-player.jpg',
    '/car-audio-speakers-subwoofer-installation.jpg'
  ]

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setItemsPerPage(3)
      } else if (window.innerWidth >= 768) {
        setItemsPerPage(2)
      } else {
        setItemsPerPage(1)
      }
    }

    handleResize()
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )
    const element = document.getElementById('testimonials-section')
    if (element) observer.observe(element)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % backgroundImages.length)
    }, 3000)
    
    return () => clearInterval(interval)
  }, [backgroundImages.length])

  const next = () => {
    setCurrentIndex((prevIndex) => {
      const maxIndex = Math.max(0, testimonials.length - itemsPerPage)
      return prevIndex + 1 > maxIndex ? 0 : prevIndex + 1
    })
  }

  const prev = () => {
    setCurrentIndex((prevIndex) => {
      const maxIndex = Math.max(0, testimonials.length - itemsPerPage)
      return prevIndex - 1 < 0 ? maxIndex : prevIndex - 1
    })
  }

  const visibleTestimonials = testimonials.slice(currentIndex, currentIndex + itemsPerPage)

  return (
    <section id="testimonials-section" className="relative py-20 md:py-32 overflow-hidden">
      <div className="absolute inset-0 z-0">
        {backgroundImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentImageIndex ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `url(${image})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundAttachment: 'fixed'
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-slate-900/95 via-slate-900/80 to-slate-900/95"></div>
          </div>
        ))}
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">Customer Reviews</h2>
          <p className="text-base md:text-lg text-slate-100 max-w-2xl mx-auto">
            See what our satisfied customers are saying about their new car radio system
          </p>
        </div>

        <div className={`relative ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {visibleTestimonials.map((testimonial, index) => (
              <div 
                key={testimonial.id}
                className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-6 md:p-8 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out"
                style={{
                  animation: isVisible ? `fadeInUp 0.6s ease-out ${index * 150}ms both` : 'none'
                }}
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star 
                      key={i} 
                      className="w-4 md:w-5 h-4 md:h-5 fill-yellow-400 text-yellow-400" 
                    />
                  ))}
                </div>

                <p className="text-sm md:text-base text-white mb-6 text-pretty leading-relaxed">
                  "{testimonial.comment}"
                </p>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-lg md:text-xl">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <p className="font-semibold text-sm md:text-base text-white">{testimonial.name}</p>
                    <p className="text-xs md:text-sm text-slate-200">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center items-center gap-4 mt-8 md:mt-12">
            <button
              onClick={prev}
              className="p-2 md:p-3 rounded-full border border-white/20 hover:bg-white/10 transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </button>

            <div className="flex gap-2">
              {Array.from({ 
                length: Math.ceil(testimonials.length / itemsPerPage) 
              }).map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 md:w-3 md:h-3 rounded-full transition-all duration-300 ease-in-out ${
                    index === currentIndex ? 'bg-blue-500' : 'bg-white/30'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>

            <button
              onClick={next}
              className="p-2 md:p-3 rounded-full border border-white/20 hover:bg-white/10 transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
