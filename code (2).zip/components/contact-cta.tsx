import { Button } from '@/components/ui/button'
import { MessageCircle, Phone, Mail } from 'lucide-react'

export default function ContactCTA() {
  return (
    <section className="py-20 md:py-32 bg-slate-900 text-white">
      <div className="max-w-4xl mx-auto px-4 md:px-6 lg:px-8 text-center space-y-8">
        <div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Upgrade Your Car?</h2>
          <p className="text-xl text-slate-300">
            Get your Android 15 2DIN car radio with GPS and wireless CarPlay today
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 py-12">
          <a href="https://wa.me/966501234567" target="_blank" rel="noopener noreferrer" className="group">
            <div className="p-6 bg-slate-800 rounded-xl hover:bg-slate-700 transition-all duration-300 ease-in-out border border-slate-700 hover:border-[#25D366] hover:shadow-lg hover:-translate-y-1">
              <MessageCircle className="w-10 h-10 text-[#25D366] mx-auto mb-3" />
              <h3 className="font-semibold mb-2">WhatsApp</h3>
              <p className="text-slate-400 text-sm">Quick response messages</p>
            </div>
          </a>

          <div className="p-6 bg-slate-800 rounded-xl border border-slate-700 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out">
            <Phone className="w-10 h-10 text-primary mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Call Us</h3>
            <p className="text-slate-400 text-sm">+966-50-1234567</p>
          </div>

          <div className="p-6 bg-slate-800 rounded-xl border border-slate-700 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out">
            <Mail className="w-10 h-10 text-primary mx-auto mb-3" />
            <h3 className="font-semibold mb-2">Email</h3>
            <p className="text-slate-400 text-sm">info@carplay.pro</p>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 justify-center">
          <a href="https://wa.me/966501234567" target="_blank" rel="noopener noreferrer">
            <Button className="gap-2 bg-[#25D366] hover:bg-[#20BA5A] text-white px-8 py-6 text-lg w-full md:w-auto hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out">
              <MessageCircle className="w-5 h-5" />
              Message on WhatsApp
            </Button>
          </a>
          <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg w-full md:w-auto hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out">
            Get Quote
          </Button>
        </div>
      </div>
    </section>
  )
}
