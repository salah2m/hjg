'use client'

import { useState, useEffect } from 'react'
import { CAROUSEL_IMAGES, CAROUSEL_INTERVAL } from '@/lib/carousel-images'
import { type Language } from '@/lib/translations'

interface ProductsHeroProps {
  language: Language
}

export default function ProductsHero({ language }: ProductsHeroProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const isArabic = language === 'ar'

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % CAROUSEL_IMAGES.length)
    }, CAROUSEL_INTERVAL)
    return () => clearInterval(timer)
  }, [])

  return (
    <section className="relative min-h-96 flex items-center justify-center overflow-hidden pt-20 pb-12">
      {/* Auto-sliding background images */}
      {CAROUSEL_IMAGES.map((img, idx) => (
        <div
          key={idx}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            idx === currentImageIndex ? 'opacity-100' : 'opacity-0'
          }`}
          style={{
            backgroundImage: `url('${img}')`,
            backgroundPosition: 'center',
            backgroundSize: 'cover',
            backgroundRepeat: 'no-repeat',
          }}
        />
      ))}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 md:px-6 max-w-3xl animate-fade-in-up">
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-balance">
          {isArabic ? 'منتجاتنا' : 'Our Products'}
        </h1>
        <p className="text-lg md:text-xl text-white/80 text-balance">
          {isArabic
            ? 'اختر من مجموعة واسعة من أنظمة الراديو والملاحة ومعدات الصوت المتقدمة'
            : 'Choose from our wide range of advanced car radio systems, navigation units, and audio equipment'}
        </p>
      </div>
    </section>
  )
}
