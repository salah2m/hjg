'use client'

import { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const backgroundImages = [
  '/car-accessories-family-4k.jpg',
  '/car-gps-navigation-system-dashboard-touchscreen.jpg',
  '/car-head-unit-multimedia-player.jpg',
  '/car-audio-speakers-subwoofer-installation.jpg',
]

const images = [
  {
    url: '/2din-android-car-radio-dashboard-display.jpg',
    title: 'Main Dashboard Display'
  },
  {
    url: '/wireless-carplay-interface-dashboard.jpg',
    title: 'CarPlay Interface'
  },
  {
    url: '/gps-navigation-map-system.jpg',
    title: 'GPS Navigation'
  },
  {
    url: '/bluetooth-audio-streaming-controls.jpg',
    title: 'Audio Controls'
  },
]

export default function Gallery() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const [bgIndex, setBgIndex] = useState(0)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )
    const element = document.getElementById('gallery-section')
    if (element) observer.observe(element)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setBgIndex((prev) => (prev + 1) % backgroundImages.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  const next = () => {
    setCurrentIndex((currentIndex + 1) % images.length)
  }

  const prev = () => {
    setCurrentIndex((currentIndex - 1 + images.length) % images.length)
  }

  return (
    <section 
      id="gallery-section" 
      className="py-20 md:py-32 relative overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(135deg, rgba(0, 0, 0, 0.7) 0%, rgba(0, 0, 0, 0.5) 100%), url(${backgroundImages[bgIndex]})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        transition: 'background-image 1s ease-in-out',
      }}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground">Product Gallery</h2>
          <p className="text-base md:text-lg text-muted-foreground">See the system in action</p>
        </div>

        <div className={`relative ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
          <div className="overflow-hidden rounded-2xl border border-border shadow-lg">
            <img 
              src={images[currentIndex].url || "/placeholder.svg"}
              alt={images[currentIndex].title}
              className="w-full h-56 sm:h-80 md:h-96 lg:h-[500px] object-cover transition-all duration-300 ease-in-out"
            />
          </div>

          <button
            onClick={prev}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 md:p-3 rounded-full transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1"
            aria-label="Previous"
          >
            <ChevronLeft className="w-5 h-5 md:w-6 md:h-6" />
          </button>

          <button
            onClick={next}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 md:p-3 rounded-full transition-all duration-300 ease-in-out hover:shadow-lg hover:-translate-y-1"
            aria-label="Next"
          >
            <ChevronRight className="w-5 h-5 md:w-6 md:h-6" />
          </button>

          <div className="text-center mt-6 md:mt-8 space-y-4">
            <p className="font-semibold text-base md:text-lg text-foreground">{images[currentIndex].title}</p>
            <div className="flex justify-center gap-2">
              {images.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 md:w-3 md:h-3 rounded-full transition-all duration-300 ease-in-out ${
                    index === currentIndex ? 'bg-primary' : 'bg-border'
                  }`}
                  aria-label={`Go to image ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
