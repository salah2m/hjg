'use client'

import { Star, MessageCircle } from 'lucide-react'
import { type Language } from '@/lib/translations'
import { type Product } from '@/lib/products-data'

interface ProductCardProps {
  product: Product
  language: Language
  index: number
}

export default function ProductCard({ product, language, index }: ProductCardProps) {
  const isArabic = language === 'ar'

  const handleWhatsApp = (e: React.MouseEvent) => {
    e.preventDefault()
    window.open(
      `https://wa.me/1234567890?text=I'm%20interested%20in%20${encodeURIComponent(product.name)}`,
      '_blank'
    )
  }

  return (
    <a
      href={`/products/${product.slug}`}
      className="group bg-white/10 backdrop-blur-md rounded-xl overflow-hidden hover:bg-white/20 transition-all duration-300 border border-white/20 hover:border-blue-400/50 transform hover:scale-105 cursor-pointer block h-full flex flex-col"
      style={{
        animation: `fadeInUp 0.6s ease-out ${index * 0.1}s backwards`,
      }}
    >
      {/* Image Section */}
      <div className="relative h-56 overflow-hidden bg-gradient-to-br from-gray-900 to-black flex-shrink-0">
        <img
          src={product.image || '/placeholder.svg'}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
      </div>

      {/* Content Section */}
      <div className="p-6 flex flex-col flex-grow">
        {/* Title & Description */}
        <div className="mb-3 flex-grow">
          <h3 className="text-lg font-bold text-white mb-1 line-clamp-2">
            {isArabic ? product.nameAr : product.name}
          </h3>
          <p className="text-sm text-white/60 line-clamp-2">
            {isArabic ? product.descriptionAr : product.description}
          </p>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-2 mb-4">
          <div className="flex gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={16}
                className={i < Math.floor(product.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-600'}
              />
            ))}
          </div>
          <span className="text-sm text-white/70">
            {product.rating} ({product.reviews} {isArabic ? 'تقييم' : 'reviews'})
          </span>
        </div>

        {/* Specs */}
        <div className="flex flex-wrap gap-2 mb-4">
          {product.specs.slice(0, 3).map((spec, i) => (
            <span key={i} className="text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded">
              {spec}
            </span>
          ))}
        </div>

        {/* Compatible */}
        <p className="text-xs text-white/50 mb-4">
          {isArabic ? 'متوافق مع: ' : 'Compatible: '} {product.compatible}
        </p>

        {/* Price & CTA */}
        <div className="flex items-center justify-between pt-4 border-t border-white/10 mt-auto">
          <p className="text-2xl font-bold text-blue-400">${product.price}</p>
          <button
            onClick={handleWhatsApp}
            className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-all duration-300 flex items-center gap-2 text-sm font-semibold"
          >
            <MessageCircle size={16} />
          </button>
        </div>
      </div>
    </a>
  )
}
