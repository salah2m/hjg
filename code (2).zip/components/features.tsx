'use client'

import { Smartphone, MapPin, Radio, Bluetooth, Volume2, Cpu, Wifi, Music } from 'lucide-react'
import { useEffect, useState } from 'react'

export default function Features() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const backgroundImages = [
    '/car-accessories-family-4k.jpg',
    '/car-gps-navigation-system-dashboard-touchscreen.jpg',
    '/car-head-unit-multimedia-player.jpg',
    '/car-audio-speakers-subwoofer-installation.jpg',
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % backgroundImages.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  const features = [
    {
      icon: Smartphone,
      title: 'Wireless CarPlay',
      description: 'Seamless iPhone integration with wireless connectivity for safe driving'
    },
    {
      icon: MapPin,
      title: 'GPS Navigation',
      description: 'Advanced mapping system with real-time traffic and voice guidance'
    },
    {
      icon: Radio,
      title: 'RDS Radio',
      description: 'Full radio band support with dynamic station information and presets'
    },
    {
      icon: Bluetooth,
      title: 'Bluetooth Audio',
      description: 'Crystal clear hands-free calls and wireless audio streaming'
    },
    {
      icon: Cpu,
      title: '8-Core Processor',
      description: 'Powerful octa-core DSP for smooth multitasking and zero lag'
    },
    {
      icon: Volume2,
      title: 'Advanced DSP',
      description: 'Professional-grade digital signal processing for superior sound'
    },
  ]

  return (
    <section 
      id="features" 
      className="py-20 md:py-32 relative overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(135deg, rgba(17, 24, 39, 0.85) 0%, rgba(31, 41, 55, 0.85) 100%), url('${backgroundImages[currentImageIndex]}')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        transition: 'background-image 0.8s ease-in-out',
      }}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Premium Features</h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Next-generation car entertainment system designed for modern drivers
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <div key={index} className="p-6 border border-white/20 rounded-xl backdrop-blur-md bg-black/40 hover:border-primary hover:shadow-lg transition-all hover:shadow-[0_0_30px_rgba(59,130,246,0.4)]">
                <div className="mb-4">
                  <Icon className="w-10 h-10 text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                <p className="text-gray-300">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
