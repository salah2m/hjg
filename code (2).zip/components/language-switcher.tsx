'use client'

import { type Language } from '@/lib/translations'
import { Globe } from 'lucide-react'

interface LanguageSwitcherProps {
  language: Language
  onLanguageChange: (lang: Language) => void
}

export default function LanguageSwitcher({ language, onLanguageChange }: LanguageSwitcherProps) {
  const languages: { code: Language; label: string; flag: string }[] = [
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'ar', label: 'العربية', flag: '🇸🇦' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
  ]

  return (
    <div className="flex items-center gap-2">
      <Globe className="w-4 h-4 text-white/60" />
      <div className="hidden md:flex gap-2">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => onLanguageChange(lang.code)}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all duration-300 ${
              language === lang.code
                ? 'bg-blue-500 text-white shadow-lg'
                : 'bg-white/10 backdrop-blur-sm text-white/60 hover:text-white hover:bg-white/20'
            }`}
            title={lang.label}
          >
            {lang.flag}
          </button>
        ))}
      </div>
      <select
        value={language}
        onChange={(e) => onLanguageChange(e.target.value as Language)}
        className="md:hidden px-3 py-1.5 rounded-md text-xs bg-white/10 backdrop-blur-sm text-white border border-white/20 focus:outline-none focus:border-blue-500"
      >
        {languages.map((lang) => (
          <option key={lang.code} value={lang.code} className="bg-slate-900 text-white">
            {lang.label}
          </option>
        ))}
      </select>
    </div>
  )
}
