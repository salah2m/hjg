'use client'

import { useState, useEffect } from 'react'
import { MessageCircle, Phone, Mail, MapPin, Zap, ChevronLeft, ChevronRight } from 'lucide-react'

export default function Footer() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isAutoPlay, setIsAutoPlay] = useState(true)

  const footerImages = [
    '/car-accessories-family-4k.jpg',
    '/car-gps-navigation-system-dashboard-touchscreen.jpg',
    '/car-head-unit-multimedia-player.jpg',
    '/car-audio-speakers-subwoofer-installation.jpg'
  ]

  useEffect(() => {
    if (!isAutoPlay) return
    
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % footerImages.length)
    }, 3000)
    
    return () => clearInterval(interval)
  }, [isAutoPlay, footerImages.length])

  return (
    <footer className="relative bg-slate-950 text-slate-300 border-t border-white/20 overflow-hidden">
      <div className="absolute inset-0">
        {footerImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
              index === currentImageIndex ? 'opacity-3' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `url(${image})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          />
        ))}
        {/* Dark overlay for readability */}
        <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-white">CarPlay Pro</span>
            </div>
            <p className="text-sm text-slate-400">
              Premium Android car entertainment systems for modern drivers.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#features" className="hover:text-blue-400 transition">Features</a></li>
              <li><a href="#specs" className="hover:text-blue-400 transition">Specifications</a></li>
              <li><a href="#gallery" className="hover:text-blue-400 transition">Gallery</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Support</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-blue-400 transition">Documentation</a></li>
              <li><a href="#" className="hover:text-blue-400 transition">Installation</a></li>
              <li><a href="#" className="hover:text-blue-400 transition">FAQ</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Contact</h4>
            <div className="space-y-3 text-sm">
              <a href="https://wa.me/966501234567" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-[#25D366] transition">
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </a>
              <a href="tel:+966501234567" className="flex items-center gap-2 hover:text-blue-400 transition">
                <Phone className="w-4 h-4" />
                +966-50-1234567
              </a>
              <a href="mailto:info@carplay.pro" className="flex items-center gap-2 hover:text-blue-400 transition">
                <Mail className="w-4 h-4" />
                info@carplay.pro
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-slate-400">
          <p>&copy; 2025 CarPlay Pro. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-blue-400 transition">Privacy Policy</a>
            <a href="#" className="hover:text-blue-400 transition">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
