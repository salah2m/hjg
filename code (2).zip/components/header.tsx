'use client'

import { useState, useEffect } from 'react'
import { Menu, X, MessageCircle, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import LanguageSwitcher from '@/components/language-switcher'
import { type Language } from '@/lib/translations'

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)
  const [currentProductIndex, setCurrentProductIndex] = useState(0)
  const [isAutoPlay, setIsAutoPlay] = useState(true)
  const [language, setLanguage] = useState<Language>('en')

  const productImages = [
    {
      src: '/2din-car-radio-android-touchscreen-dashboard-displ.jpg',
      alt: 'Android Car Radio 2DIN'
    },
    {
      src: '/car-gps-navigation-system-dashboard-touchscreen.jpg',
      alt: 'GPS Navigation System'
    },
    {
      src: '/car-head-unit-multimedia-player.jpg',
      alt: 'Multimedia Head Unit'
    }
  ]

  useEffect(() => {
    if (!isAutoPlay) return
    
    const interval = setInterval(() => {
      setCurrentProductIndex((prev) => (prev + 1) % productImages.length)
    }, 3000)
    
    return () => clearInterval(interval)
  }, [isAutoPlay, productImages.length])

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language | null
    if (savedLanguage) {
      setLanguage(savedLanguage)
      document.documentElement.lang = savedLanguage
      document.documentElement.dir = savedLanguage === 'ar' ? 'rtl' : 'ltr'
    }
  }, [])

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang)
    localStorage.setItem('language', lang)
    document.documentElement.lang = lang
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'
  }

  return (
    <header className="relative z-50 bg-gradient-to-r from-slate-900/98 via-slate-900/96 to-slate-900/98 backdrop-blur-lg border-b border-blue-500/30 shadow-lg">
      <nav className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-3 md:py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-8 h-8 md:w-10 md:h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center hover:shadow-lg transition-all">
            <Zap className="w-5 h-5 md:w-6 md:h-6 text-white" />
          </div>
          <span className="hidden sm:inline text-base md:text-lg font-bold text-white">CarPlay Pro</span>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-6 lg:gap-8">
          <a href="/" className="text-sm text-white/80 hover:text-blue-400 transition duration-300">Home</a>
          <a href="/#features" className="text-sm text-white/80 hover:text-blue-400 transition duration-300">Features</a>
          <a href="/#specs" className="text-sm text-white/80 hover:text-blue-400 transition duration-300">Specs</a>
          <a href="/products" className="text-sm text-white/80 hover:text-blue-400 transition duration-300">Products</a>
          <a href="/#gallery" className="text-sm text-white/80 hover:text-blue-400 transition duration-300">Gallery</a>
        </div>

        {/* Language Switcher + WhatsApp - Desktop */}
        <div className="hidden md:flex items-center gap-4 flex-shrink-0">
          <LanguageSwitcher language={language} onLanguageChange={handleLanguageChange} />
          <a href="https://wa.me/966501234567" target="_blank" rel="noopener noreferrer">
            <Button className="gap-1.5 bg-[#25D366] hover:bg-[#20BA5A] text-white text-sm px-4 py-2 hover:shadow-lg transition-all duration-300">
              <MessageCircle className="w-4 h-4" />
              <span>Chat</span>
            </Button>
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-white flex-shrink-0" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden border-t border-white/10 bg-slate-900/95 backdrop-blur-md">
          <div className="px-4 py-3 space-y-3 max-h-64 overflow-y-auto">
            <a href="/" className="block text-sm text-white/80 hover:text-blue-400 py-2">Home</a>
            <a href="/#features" className="block text-sm text-white/80 hover:text-blue-400 py-2">Features</a>
            <a href="/#specs" className="block text-sm text-white/80 hover:text-blue-400 py-2">Specifications</a>
            <a href="/products" className="block text-sm text-white/80 hover:text-blue-400 py-2">Products</a>
            <a href="/#gallery" className="block text-sm text-white/80 hover:text-blue-400 py-2">Gallery</a>
            
            <div className="pt-3 border-t border-white/10">
              <p className="text-xs text-white/60 mb-2">Select Language / اختر اللغة / Sélectionner la langue</p>
              <div className="flex gap-2">
                {[{ code: 'en' as Language, label: '🇬🇧 EN' }, 
                  { code: 'ar' as Language, label: '🇸🇦 AR' }, 
                  { code: 'fr' as Language, label: '🇫🇷 FR' }].map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => handleLanguageChange(lang.code)}
                    className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all duration-300 flex-1 ${
                      language === lang.code
                        ? 'bg-blue-500 text-white shadow-lg'
                        : 'bg-white/10 text-white/60 hover:text-white'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>

            <a href="https://wa.me/966501234567" target="_blank" rel="noopener noreferrer">
              <Button className="w-full gap-2 bg-[#25D366] hover:bg-[#20BA5A] text-white text-sm py-2">
                <MessageCircle className="w-4 h-4" />
                Chat on WhatsApp
              </Button>
            </a>
          </div>
        </div>
      )}
    </header>
  )
}
