'use client'

import { useEffect, useState } from 'react'

export default function Specifications() {
  const [isVisible, setIsVisible] = useState(false)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const backgroundImages = [
    '/car-accessories-family-4k.jpg',
    '/car-gps-navigation-system-dashboard-touchscreen.jpg',
    '/car-head-unit-multimedia-player.jpg',
    '/car-audio-speakers-subwoofer-installation.jpg',
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % backgroundImages.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )
    const element = document.getElementById('specs-section')
    if (element) observer.observe(element)
    return () => observer.disconnect()
  }, [])

  const specs = [
    { 
      category: 'System', 
      items: [
        { label: 'Operating System', value: 'Android 15' },
        { label: 'Processor', value: '8-Core DSP' },
        { label: 'RAM', value: '4GB' },
        { label: 'Storage', value: '64GB eMMC' },
      ]
    },
    { 
      category: 'Connectivity', 
      items: [
        { label: 'CarPlay', value: 'Wireless & Wired' },
        { label: 'Bluetooth', value: '5.2' },
        { label: 'WiFi', value: '802.11 ac/ax' },
        { label: 'GPS', value: 'Multi-GNSS' },
      ]
    },
    { 
      category: 'Media & Sound', 
      items: [
        { label: 'Radio', value: 'FM/AM + RDS' },
        { label: 'Audio Format', value: 'MP3, FLAC, AAC, OGG' },
        { label: 'Video Support', value: 'MP4, MKV, AVI, MOV' },
        { label: 'DSP', value: '8-Channel' },
      ]
    },
    { 
      category: 'Hardware', 
      items: [
        { label: 'Display', value: '7-10 inch IPS' },
        { label: 'Touch', value: 'Capacitive' },
        { label: 'DIN Standard', value: '2-DIN' },
        { label: 'Compatibility', value: 'Peugeot 208/2008' },
      ]
    },
  ]

  return (
    <section 
      id="specs-section" 
      className="py-20 md:py-32 relative overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(135deg, rgba(17, 24, 39, 0.85) 0%, rgba(31, 41, 55, 0.85) 100%), url('${backgroundImages[currentImageIndex]}')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        transition: 'background-image 0.8s ease-in-out',
      }}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white">Technical Specifications</h2>
          <p className="text-base md:text-lg text-gray-300 max-w-2xl mx-auto">
            Complete system specifications for optimal performance
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 lg:gap-8">
          {specs.map((section, idx) => (
            <div 
              key={idx} 
              className={`bg-black/40 backdrop-blur-md rounded-xl p-6 border border-white/20 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out hover:shadow-[0_0_30px_rgba(59,130,246,0.4)] ${
                isVisible ? 'animate-fade-in-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              <h3 className="font-bold text-lg text-white mb-4">{section.category}</h3>
              <div className="space-y-4">
                {section.items.map((item, i) => (
                  <div key={i} className="pb-3 border-b border-white/20 last:border-b-0">
                    <p className="text-xs md:text-sm text-gray-300 mb-1">{item.label}</p>
                    <p className="font-semibold text-sm md:text-base text-white">{item.value}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
