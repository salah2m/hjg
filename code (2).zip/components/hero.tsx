'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { MessageCircle, ChevronRight, ChevronLeft } from 'lucide-react'

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isAutoPlay, setIsAutoPlay] = useState(true)

  const heroImages = [
    {
      src: '/car-accessories-family-4k.jpg',
      alt: 'Car Radio & Audio Systems',
      title: 'Audio Systems'
    },
    {
      src: '/car-gps-navigation-system-dashboard-touchscreen.jpg',
      alt: 'GPS Navigation Systems',
      title: 'Navigation'
    },
    {
      src: '/car-head-unit-multimedia-player.jpg',
      alt: 'Multimedia Head Units',
      title: 'Multimedia'
    },
    {
      src: '/car-audio-speakers-subwoofer-installation.jpg',
      alt: 'Speaker & Audio Accessories',
      title: 'Audio Accessories'
    }
  ]

  useEffect(() => {
    setIsVisible(true)
  }, [])

  useEffect(() => {
    if (!isAutoPlay) return
    
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % heroImages.length)
    }, 3000)
    
    return () => clearInterval(interval)
  }, [isAutoPlay, heroImages.length])

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % heroImages.length)
    setIsAutoPlay(false)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + heroImages.length) % heroImages.length)
    setIsAutoPlay(false)
  }

  return (
    <section className="min-h-screen relative overflow-hidden flex items-center justify-center py-20">
      <div className="absolute inset-0 z-0">
        {heroImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentImageIndex ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `url(${image.src})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundAttachment: 'fixed'
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-900/90"></div>
          </div>
        ))}
      </div>

      {/* Category indicator */}
      <div className="absolute top-24 md:top-32 left-0 right-0 z-20 flex justify-center">
        <div className="flex gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full border border-white/20">
          {heroImages.map((image, index) => (
            <button
              key={index}
              onClick={() => {
                setCurrentImageIndex(index)
                setIsAutoPlay(false)
              }}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-all duration-300 ${
                index === currentImageIndex
                  ? 'bg-blue-500 text-white'
                  : 'bg-white/10 text-white/70 hover:bg-white/20'
              }`}
            >
              {image.title}
            </button>
          ))}
        </div>
      </div>

      {/* Content overlay */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-12 md:py-0 grid md:grid-cols-2 gap-8 md:gap-12 items-center w-full">
        <div className={`space-y-8 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
          <div className="space-y-4">
            <span className="inline-block px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm font-medium border border-blue-500/30">
              Latest Technology
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-balance text-white drop-shadow-lg">
              Android 15 Car Radio 2DIN
            </h1>
            <p className="text-lg md:text-xl text-slate-100 text-pretty drop-shadow-md">
              Complete automotive multimedia system with wireless CarPlay & GPS navigation designed specifically for Peugeot 208 and 2008
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <a href="https://wa.me/966501234567" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
              <Button className="gap-2 bg-[#25D366] hover:bg-[#20BA5A] text-white px-6 md:px-8 py-5 md:py-6 text-base md:text-lg w-full hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out">
                <MessageCircle className="w-5 h-5" />
                Order via WhatsApp
              </Button>
            </a>
            <Button variant="outline" className="gap-2 border-white text-white hover:bg-white/10 px-6 md:px-8 py-5 md:py-6 text-base md:text-lg w-full hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out">
              Learn More
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-4 pt-8 border-t border-white/10 bg-white/5 p-4 rounded-lg backdrop-blur-sm">
            <div className="space-y-1">
              <p className="text-2xl md:text-3xl font-bold text-white">Android 15</p>
              <p className="text-sm md:text-base text-slate-300">Latest OS</p>
            </div>
            <div className="space-y-1">
              <p className="text-2xl md:text-3xl font-bold text-white">8-Core</p>
              <p className="text-sm md:text-base text-slate-300">DSP</p>
            </div>
            <div className="space-y-1">
              <p className="text-2xl md:text-3xl font-bold text-white">GPS</p>
              <p className="text-sm md:text-base text-slate-300">Navigation</p>
            </div>
          </div>
        </div>

        <div className={`hidden md:flex items-center justify-center relative ${isVisible ? 'animate-slide-in-right' : 'opacity-0'}`}>
          <div className="relative w-full max-w-md">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl blur-3xl opacity-30 animate-glow"></div>
            <img 
              src="/2din-car-radio-android-touchscreen-dashboard-displ.jpg"
              alt="Android Car Radio 2DIN"
              className="relative w-full rounded-2xl shadow-2xl border border-white/10"
            />
          </div>

          {/* Navigation buttons */}
          <button
            onClick={prevImage}
            className="absolute -left-16 top-1/2 -translate-y-1/2 p-2 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full text-white transition-all duration-300 border border-white/20 hover:border-white/40"
            aria-label="Previous image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextImage}
            className="absolute -right-16 top-1/2 -translate-y-1/2 p-2 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full text-white transition-all duration-300 border border-white/20 hover:border-white/40"
            aria-label="Next image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        <div className="md:hidden">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl blur-2xl opacity-30"></div>
            <img 
              src="/2din-car-radio-android-touchscreen-dashboard-displ.jpg"
              alt="Android Car Radio 2DIN"
              className="relative w-full rounded-2xl shadow-xl border border-white/10"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
