# Hosting Compatibility Guide

This application is built with Next.js and can be deployed on multiple hosting platforms.

## Deployment Options

### 1. Vercel (Recommended - Fastest)
- Automatic deployments from GitHub
- Zero configuration needed
- Free tier available
- Visit: https://vercel.com/new

**Steps:**
1. Push code to GitHub
2. Connect GitHub to Vercel
3. Vercel automatically detects Next.js and deploys

### 2. WordPress Hosting (Kinsta, WP Engine)
These platforms support Node.js applications.

**Steps:**
1. Build static export: `npm run build:static`
2. Upload `out/` folder to your hosting
3. Configure web server to serve `index.html` for all routes

### 3. Traditional Hosting (Bluehost, HostGator, SiteGround)
For WordPress hosting without Node.js support:

**Static Export (Recommended):**
\`\`\`bash
npm run build:static
# Upload contents of 'out/' folder to public_html/
\`\`\`

**With Node.js Support:**
\`\`\`bash
npm install
npm run build
npm start
\`\`\`

### 4. Netlify
- Easy deployment from GitHub
- Automatic builds
- Free SSL

**Steps:**
1. Connect GitHub repository
2. Set build command: `npm run build`
3. Set publish directory: `.next`

### 5. Docker (Any hosting with Docker support)
\`\`\`bash
docker build -t car-store .
docker run -p 3000:3000 car-store
\`\`\`

## Production Build Scripts

Add these scripts to package.json:

\`\`\`json
"build": "next build",
"build:static": "EXPORT_STATIC=true next build && next export",
"start": "next start",
"export": "next export"
\`\`\`

## Environment Variables for Different Platforms

### Vercel
Set in Project Settings → Environment Variables

### Netlify
Set in Site Settings → Build & Deploy → Environment

### WordPress/Traditional Hosting
Create `.env.local` or `.env.production` file

## SEO & Performance Tips

- Meta tags are pre-configured in layout.tsx
- Images are optimized with `next/image`
- CSS is minified automatically
- JavaScript is minified automatically

## Support & Testing

1. Test locally: `npm run dev`
2. Build locally: `npm run build`
3. Start production: `npm start`
4. Generate static files: `npm run build:static`

## Troubleshooting

**Images not showing:**
- Check image paths start with `/`
- Ensure images are in `public/` folder

**Routes not working:**
- Next.js requires proper routing structure
- All page files must be in `app/` directory

**CSS not loading:**
- Clear browser cache
- Check `app/globals.css` is imported in layout

## WordPress Plugin Integration

To integrate this as an embedded widget on WordPress:
1. Generate static export
2. Upload to WordPress media library
3. Embed using iframe or custom plugin

For full WordPress theme integration, contact support.
